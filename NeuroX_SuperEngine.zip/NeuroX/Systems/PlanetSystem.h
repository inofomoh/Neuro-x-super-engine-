#pragma once

namespace PlanetSystem {
    void InitPlanets();
    void UpdatePlanets();
}