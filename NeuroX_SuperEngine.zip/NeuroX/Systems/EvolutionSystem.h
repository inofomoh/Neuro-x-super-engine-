#pragma once

namespace EvolutionSystem {
    void InitCreatures();
    void EvolveCreatures();
}