#pragma once

namespace VehicleSystem {
    void InitVehicles();
    void SimulateVehicles();
}