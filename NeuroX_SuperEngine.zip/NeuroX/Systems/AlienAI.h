#pragma once

namespace AlienAI {
    void InitAliens();
    void SimulateAliens();
}