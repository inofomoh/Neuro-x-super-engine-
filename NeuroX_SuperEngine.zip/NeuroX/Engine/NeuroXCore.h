#pragma once

class NeuroXEngine {
public:
    void Initialize();
    void Run();
};