#include "Engine/NeuroXCore.h"

int main() {
    NeuroXEngine engine;
    engine.Initialize();
    engine.Run();
    return 0;
}